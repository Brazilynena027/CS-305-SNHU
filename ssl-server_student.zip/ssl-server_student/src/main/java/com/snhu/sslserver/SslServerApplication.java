package com.snhu.sslserver;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

// main method that will run the spring boot application
@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}
//FIXME: Add route to enable check sum return of static data example:  String data = "Hello World Check Sum!";

@RestController
class ServerController {
	
	// generates and returns the hash of a name.

    @GetMapping("/hash")
    public String hello(@RequestParam(value = "name", defaultValue = "Danielle Sousa") String name) {
        try {
        	//returns name in default value
            return generateHash(name);
        } catch (NoSuchAlgorithmException e) {
        	
        	//exception if the hashing algorithm is not found
            return "Error: Unable to generate hash";
        }
    }
    //generates the SHA-256 hash of the data that is given
    
    public String generateHash(String data) throws NoSuchAlgorithmException {
        MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
        
        //digest with byte  data
        messageDigest.update(data.getBytes());
        
        // hash calculation
        byte[] digest = messageDigest.digest();
        
        //byte array to hex string.
        StringBuilder hexString = new StringBuilder();
        for (byte b : digest) {
            hexString.append(Integer.toHexString(0xFF & b));
        }

        // returns the result of the string HTML
        return String.format("<p>%s</p><p>Hello World Check Sum! %s</p>", data, hexString.toString());
    }
}